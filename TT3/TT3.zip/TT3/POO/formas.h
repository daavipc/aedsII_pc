class retangulo{
private:
double base;
double altura;

public:
retangulo(double base, double altura);
double getArea();
double getPerimetro();
double getDiagonal();
};
